create function date_part(text, date) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN date_part($1, ($2)::timestamp without time zone);

comment on function date_part(text, date) is 'extract field from date';

alter function date_part(text, date) owner to postgres;

